<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Chart.js - graphics</title>
		<!--
		<link rel="stylesheet" href="assets/demo.css">
		<script src="../node_modules/dat.gui/build/dat.gui.min.js"></script>
		<script src="../tracking.js-master/assets/stats.min.js"></script>
		-->
		<script src="Chart.bundle.js"></script>
		
		<style>
			body {  
				background: floralwhite;
				padding: 16px;
			}
				
			canvas {
				border: 1px dotted black;
			}
				
			.chart-container {
				position: relative;
				margin: 0px;
				height: 45vh;
				width: 70vw;
			}
			
			#testo {
				border: 1px dotted black;
				width: 25vw;
				height: 100%;
				float: right;
				padding: 5px 5px;
				text-align: center;
			}
		</style>
		
	</head>
	<body> 
		<div id="testo">
			<h1>Progetto - FaceDetection</h1>
		</div>
		<div class="chart-container">
			<canvas id="chartNumeroVisite"></canvas>
			<br>
			<canvas id="chartTempoMedio"></canvas>
		</div>
		
		<?php
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "facedetection";
			$conn = new mysqli($servername, $username, $password, $dbname);
			
			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			
			$sql = "SELECT Orario_inizio, Orario_fine, Data FROM webcam";
			$result = $conn->query($sql);
			
			$Orario_inizio=array();
			$Orario_fine=array();
			$Data=array();
			$arrayIndex = 0;
			
			if ($result->num_rows > 0) {
				// output data of each row
				while($row = $result->fetch_assoc()) {
					array_push($Orario_inizio, $row["Orario_inizio"]);
					array_push($Orario_fine, $row["Orario_fine"]);
					array_push($Data, $row["Data"]);
				}
			} else {
				echo "0 results";
			}
			
			$conn->close();
		?>
		<script>
		
		//Popola l'array con gli orari di inizio del tracking.
		var count = <?php echo count($Orario_inizio); ?>;
		var Orario_inizio = ["","","","","","","","","","","","","",""];
		for(i=0; i < count; i++) {
			Orario_inizio[i] = "<?php echo $Orario_inizio[$arrayIndex+=1]; ?>";
		}
		<?php $arrayIndex = 0; ?>

		//Popola l'array con gli orari di fine del tracking.
		var count = <?php echo count($Orario_fine); ?>;
		var Orario_fine = ["","","","","","","","","","","","","",""];
		for(i=0; i < count; i++) {
			Orario_fine[i] = "<?php echo $Orario_fine[$arrayIndex+=1]; ?>";
		}
		<?php $arrayIndex = 0; ?>
		
		//Popola l'array con le date del tracking.
		var count = <?php echo count($Data); ?>;
		var Data = ["","","","","","","","","","","","","",""];
		for(i=0; i < count; i++) {
			Data[i] = "<?php echo $Data[$arrayIndex+=1]; ?>";
		}
		<?php $arrayIndex = 0; ?>
		
		for(i = 0; i < count; i++) {
			document.getElementById("testo").innerHTML += "- "+Orario_inizio[i]+", "+Orario_fine[i]+", "+Data[i]+"<br>";
		}
		document.getElementById("testo").innerHTML += "<br>- "+Orario_inizio[0]+", "+Orario_inizio[1]+", "+Orario_inizio[2];
		
		var dataNumeroVisite = {
			labels: ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00"],
			datasets: [{
				label: "Numero di visite",
				backgroundColor: "rgba(255,99,132,0.2)",
				borderColor: "rgba(255,99,132,1)",
				borderWidth: 2,
				hoverBackgroundColor: "rgba(255,99,132,0.4)",
				hoverBorderColor: "rgba(255,99,132,1)",
				data: [65, 59, 20, 81, 56, 55, 40, 35, 24, 78, 13, 35, 86, 24],
			}]
		};
			
		var optionsNumeroVisite = {
			maintainAspectRatio: false,
			scales: {
				yAxes: [{
				stacked: true,
				gridLines: {
					display: true,
					color: "rgba(255,99,132,0.2)"
				}
				}],
				xAxes: [{
				gridLines: {
					display: false
				}
				}]
			}
		};
		
		var dataTempoMedio = {
			labels: ["09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00"],
			datasets: [{
				label: "Tempo medio di visita",
				backgroundColor: "rgba(99,132,255,0.2)",
				borderColor: "rgba(99,132,255,1)",
				borderWidth: 2,
				hoverBackgroundColor: "rgba(99,132,255,0.4)",
				hoverBorderColor: "rgba(99,132,255,1)",
				data: [65, 59, 20, 81, 56, 55, 40, 35, 24, 78, 13, 35, 86, 24],
			}]
		};
			
		var optionsTempoMedio = {
			maintainAspectRatio: false,
			scales: {
				yAxes: [{
				stacked: true,
				gridLines: {
					display: true,
					color: "rgba(99,132,255,0.2)"
				}
				}],
				xAxes: [{
				gridLines: {
					display: false
				}
				}]
			}
		};
		
		Chart.Bar('chartNumeroVisite', {
			options: optionsNumeroVisite,
			data: dataNumeroVisite
		});
		Chart.Bar('chartTempoMedio', {
			options: optionsTempoMedio,
			data: dataTempoMedio
		});
		
		</script>
	</body>
</html>